##############################################
################# READ ME ####################
##############################################

Our project represent connected Bicycles.
Alert messages are sent in real-time when a bicycle is going to slow.
Some data analysis is performed on stored data.

Our Architecture:
Random Data generated -> stream through kafka -> alert messages shown
We wanted to store the generated data into HBase, but failed to run HBase,
so we stored it in a text file when streaming (data.json)

Part A) Monitoring:
- run kafka
- run ProducerWindow.scala and ConsumerWindow.scala

Part B) Storing and Analytics:
- run Analysis.scala (reads data.json file and uses Spark SQL to perform queries)
- the results are stored in the .csv files:
   - battery_failure.csv -> percentage of devices that failed because of low battery among failed devices
   - failedNH.csv -> number of failed devices in the Northern Hemisphere
   - failedSH.csv -> number of failed devices in the Southern Hemisphere




