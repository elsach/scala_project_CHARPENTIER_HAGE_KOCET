package classes

import java.util.Properties

import classes.{ Bicycle, Location }
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord, RecordMetadata}

import scala.util.{Failure, Success, Try}
import scala.math.BigInt

case class Producer(bicycles: Int = 3, brokers : String, topic: String){

  private final val serializer = "org.apache.kafka.common.serialization.StringSerializer"
  private lazy val currentKafkaProducer: Try[KafkaProducer[String, String]] = Try(new KafkaProducer[String, String](configuration))
  private def configuration: Properties = {
    val props = new Properties()
    props.put("bootstrap.servers","localhost:9092")
    props.put("key.serializer", serializer)
    props.put("value.serializer", serializer)
    props
  }

  def send(msg: String): Try[java.util.concurrent.Future[RecordMetadata]] = {
    currentKafkaProducer match {
      case Success(p) => {
        val data = new ProducerRecord[String, String](topic, msg)
        Success(p.send(data))
      }
      case Failure(e) => Failure(e)
    }
  }

  def close:Unit = {
    currentKafkaProducer match {
      case Success(p) => {
        p.close()
      }
      case Failure(e) => throw e
    }
  }

  def isValid : Boolean = bicycles > 0 && topic.nonEmpty
}

object Producer {
  final val minSpeed = 0
  final val maxSpeed = 40
  private var id: Long = 0
  private val rnd = new scala.util.Random
  def generateRandomData(bicycleIds: Array[String]): Array[Bicycle] = {
    val bicycles = new Array[Bicycle](bicycleIds.length)

    for (i <- 0 to bicycles.length - 1) {
      val battery = generateBattery
      if(battery == 0) {
           bicycles(i) = Bicycle(bicycleIds(i), generateSpeed, System.currentTimeMillis, generateLocation, battery, true)
      }
      else {
        bicycles(i) = Bicycle(bicycleIds(i), generateSpeed, System.currentTimeMillis, generateLocation, battery, generateFailure)
      }
    }
    bicycles
  }

  def generateSpeed: Int = {
    val rnd = new scala.util.Random
    minSpeed + rnd.nextInt((maxSpeed - minSpeed) + 1)
  }

  def generateLocation: Location = {
    val lat = new scala.util.Random
    val lon = new scala.util.Random
    Location(-90 + lat.nextDouble()*180, -180 + lon.nextDouble()*360)
  }

  def generateBattery: Int = {
    val rnd = new scala.util.Random
    rnd.nextInt(100)
  }

  def generateFailure: Boolean = {
    val rnd = new scala.util.Random
    val num = rnd.nextFloat()
    if(num < 0.05) {
      true
    }
    else {
      false
    }
  }
}
