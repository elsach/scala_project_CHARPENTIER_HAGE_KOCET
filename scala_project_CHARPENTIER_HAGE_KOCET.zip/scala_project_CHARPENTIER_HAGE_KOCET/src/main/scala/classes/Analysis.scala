package classes

import org.apache.spark.{SparkConf, SparkContext, sql}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object Analysis {
  def main( args:Array[String] ):Unit = {
    val conf = new SparkConf()
                        .setAppName("Project")
                        .setMaster("local[*]")
    val ss = SparkSession.builder()
      .appName("Project")
      .master("local[*]")
      .getOrCreate()
    val path = "data.json"
    val bicycleDF = ss.read.option("multiline", "true").json("data.json")
    bicycleDF.printSchema()
    bicycleDF.show(false)

    // Creates a temporary view using the DataFrame
    bicycleDF.createOrReplaceTempView("bicycles")

    // Failed devices in northern hemisphere
    val failedNHDF = ss.sql("SELECT COUNT(*) AS failedNH FROM bicycles WHERE failed AND location.latitude > 0")
    failedNHDF.show()
    failedNHDF.select("failedNH").write.format("csv").option("header", "true").save("failedNH.csv")
    // Failed devices in southern hemisphere
    val failedSHDF = ss.sql("SELECT COUNT(*) AS failedSH FROM bicycles WHERE failed AND location.latitude < 0")
    failedSHDF.show()
    failedSHDF.select("failedSH").write.format("csv").option("header", "true").save("failedSH.csv")

    // percentages of failures due to low battery
    // failed devices
    val failedDF = ss.sql("SELECT * FROM bicycles WHERE failed")
    failedDF.createOrReplaceTempView("failedDevices")
    val failedLowBat = ss.sql("SELECT COUNT(f1.*)*100/(SELECT COUNT(*) FROM failedDevices) AS Percentage_Battery_Failure FROM failedDevices AS f1 WHERE f1.battery = 0")
    failedLowBat.show()
     failedLowBat.select("Percentage_Battery_Failure").write.format("csv").option("header", "true").save("battery_failure.csv")

  }
}
