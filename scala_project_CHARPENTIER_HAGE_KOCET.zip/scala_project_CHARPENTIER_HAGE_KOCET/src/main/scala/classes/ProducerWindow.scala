package classes

import java.awt.Dimension
import scala.swing.Dialog.Message
import scala.swing._
import scala.swing.event.ButtonClicked
import scala.util.control.NonFatal
import scala.util.{Failure, Success}

object ProducerWindow extends SimpleSwingApplication{
  def top = new MainFrame {
    preferredSize = new Dimension(500, 140)

    title = "Producer"

    import Producer._

    private var totalSentMessages: Int = 0

    def sendMessage: Unit = {
      val bicycles = generateRandomData(bicycleIds)

      try {
        for (d <- bicycles) {
          val results = producer.send(d.toJson)
          results match {
            case Success(_) => {
              totalSentMessages += 1
              totalSentMessagesTxt.text = totalSentMessages.toString
            }
            case Failure(e) => throw e
          }

        }
      } catch {
        case NonFatal(e) => {
          timer.stop()
          Dialog.showMessage(contents.head, e.getMessage, title = "Error", Message.Error)
        }
      }

    }

    val onTimer = new javax.swing.AbstractAction() {
      def actionPerformed(e: java.awt.event.ActionEvent) = sendMessage
    }
    val timer = new javax.swing.Timer(2000, onTimer)

    val bicyclesLbl = new Label {
      text = "Bicycles:"
    }
    val bicyclesTxt = new TextField {
      text = "3"
    }

    val topicLbl = new Label {
      text = "Topic:"
    }
    val topicTxt = new TextField {
      text = "project"
    }

    val totalSentMessagesLbl = new Label {
      text = "Total sent:"
    }
    val totalSentMessagesTxt = new TextField {
      text = "0";
      editable = false
    }
    val startBtn = new Button("Start")
    val stopBtn = new Button("Stop")
    listenTo(startBtn, stopBtn)

    reactions += {
      case ButtonClicked(`startBtn`) => startSending
      case ButtonClicked(`stopBtn`) => stopSending
    }

    contents = new BoxPanel(Orientation.Vertical) {
      contents += new BoxPanel(Orientation.Horizontal) {
        contents += bicyclesLbl
        contents += bicyclesTxt
        contents += Swing.HStrut(10)
        contents += Swing.HStrut(10)
        contents += topicLbl
        contents += topicTxt
      }

      contents += Swing.VStrut(40)
      contents += new BoxPanel(Orientation.Horizontal) {
        contents += startBtn
        contents += Swing.HStrut(10)
        contents += stopBtn
        contents += Swing.HStrut(100)
        contents += totalSentMessagesLbl
        contents += totalSentMessagesTxt
      }

      border = Swing.EmptyBorder(10, 10, 10, 10)
    }
    var producer: Producer = null
    var bicycleIds: Array[String] = null

    def startSending: Unit = {
      producer = Producer(bicyclesTxt.text.toInt, "localhost:9092", topicTxt.text)

      if (!producer.isValid) {
        Dialog.showMessage(contents.head, "Invalid input. Please specify number of devices and kafka topic.", title = "Invalid input", Message.Error)
        return
      }
      import Array._
      bicycleIds = range(1,bicyclesTxt.text.toInt).map(_.toString)

      timer.start()
    }

    def stopSending: Unit = {

      producer.close

      if (timer.isRunning) timer.stop()
    }
  }
}
