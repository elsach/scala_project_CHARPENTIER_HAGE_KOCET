package classes

import scala.swing._
import scala.swing.event.ButtonClicked
import scala.swing.SimpleSwingApplication
import java.awt.Dimension
import scala.swing.Dialog.Message
import scala.util.control.NonFatal
import scala.util.{Failure, Success}

object ConsumerWindow extends SimpleSwingApplication {
  def top = new MainFrame {
    preferredSize = new Dimension(550, 140)

    title = "Consumer"

    private var totalReceivedMessages: Int = 0
    
    import java.io._
    val pw = new PrintWriter(new File("data.json"))
    pw.write("[\n")

    def receiveMessages: Unit = {

      try {
        val messages = consumer.receive
	import Bicycle._
        messages match {
          case Success(seq: Seq[String]) => {
            for (m <- seq) {
              totalReceivedMessages += 1
              totalReceivedMessagesTxt.text = totalReceivedMessages.toString
	      pw.write(m)
	      val received_bicycle = parse(m)
	      if (received_bicycle.speed < 5) {
		val text = s"Bicycle with id ${received_bicycle.bicycleId} is going too slow!\nSpeed: ${received_bicycle.speed}"
	      	Dialog.showMessage(contents.head, text, title = "Speed too low!", Message.Error)
              }
            }
          }
          case Failure(e) => throw e
        }
      } catch {
        case NonFatal(e) => {
          timer.stop()
          Dialog.showMessage(contents.head, e.getMessage, title = "Error", Message.Error)
        }
      }
    }

    val onTimer = new javax.swing.AbstractAction() {
      def actionPerformed(e: java.awt.event.ActionEvent) = receiveMessages
    }
    val timer = new javax.swing.Timer(2000, onTimer)

    val topicLbl = new Label {
      text = "Topic:"
    }
    val topicTxt = new TextField {
      text = "project"
    }

    val totalReceivedMessagesLbl = new Label {
      text = "Total received:"
    }
    val totalReceivedMessagesTxt = new TextField {
      text = "0";
      editable = false
    }
    val startBtn = new Button("Start")
    val stopBtn = new Button("Stop")
    listenTo(startBtn, stopBtn)

    reactions += {
      case ButtonClicked(`startBtn`) => startReceiving
      case ButtonClicked(`stopBtn`) => stopReceiving
    }

    contents = new BoxPanel(Orientation.Vertical) {
      contents += new BoxPanel(Orientation.Horizontal) {
        contents += Swing.HStrut(100)
        contents += topicLbl
        contents += topicTxt
	contents += Swing.HStrut(100)
      }

      contents += Swing.VStrut(40)
      contents += new BoxPanel(Orientation.Horizontal) {
        contents += startBtn
        contents += Swing.HStrut(10)
        contents += stopBtn
        contents += Swing.HStrut(100)
        contents += totalReceivedMessagesLbl
        contents += totalReceivedMessagesTxt
      }

      border = Swing.EmptyBorder(10, 10, 10, 10)
    }
    var consumer: Consumer = null

    def startReceiving: Unit = {
      consumer = Consumer("localhost:9092", topicTxt.text)
      timer.start()
    }

    def stopReceiving: Unit = {
      consumer.close
      pw.write("]")
      pw.close
      if (timer.isRunning) timer.stop()
    }
  }
}
