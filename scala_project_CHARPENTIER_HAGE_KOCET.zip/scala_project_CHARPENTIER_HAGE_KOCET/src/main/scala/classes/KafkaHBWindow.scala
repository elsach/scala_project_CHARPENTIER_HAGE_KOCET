package classes

import java.awt.Dimension

import classes.HBaseProxy
import javax.swing.BorderFactory
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.StreamingQuery

import scala.swing.Dialog.Message
import scala.swing.{BoxPanel, SimpleSwingApplication, _}
import scala.swing.event.ButtonClicked
import scala.util.control.NonFatal

object KafkaHBWindow extends SimpleSwingApplication{
  def top = new MainFrame {

    title = "Kafka to HBase receiver"

    def getMessages: Unit = {

      try {
        if(squery.isActive)
          totalSavedMessagesTxt.text = hbase.getCount.toString
        else{
          throw new Throwable("Spark job failed.")
        }
      } catch {
        case NonFatal(e) => {
          if(timer.isRunning) timer.stop()
          sparkJob.stop
          Dialog.showMessage(contents.head, e.getMessage, title = "Error", Message.Error)
        }
      }
    }

    val onTimer = new javax.swing.AbstractAction() {
      def actionPerformed(e: java.awt.event.ActionEvent) = getMessages
    }
    val timer = new javax.swing.Timer(2000, onTimer)

    /**
      * Kafka settings
      */
    val pollTimeoutLbl = new Label {
      text = "Polling timeout(ms):"
    }
    val pollTimeoutTxt = new TextField {
      text = "500"
    }
    val topicLbl = new Label {
      text = "Topic:"
    }
    val topicTxt = new TextField {
      text = "project"
    }

    /**
      * ZookKeeper settings
      */
    val zkTableLbl = new Label {
      text = "Table name:"
    }
    val zkTableTxt = new TextField {
      text = "Project"
    }

    val zkQuorumLbl = new Label {
      text = "Quorum:"
    }
    val zkQuorumTxt = new TextField {
      text = "localhost"
    }

    val zkPortLbl = new Label {
      text = "Port:"
    }
    val zkPortTxt = new TextField {
      text = "2181"
    }

    val zkZNodeParentLbl = new Label {
      text = "ZNode parent:"
    }
    val zkZNodeParentTxt = new TextField {
      text = "/hbase-unsecure"
    }

    val zkRootDirLbl = new Label {
      text = "Root dir:"
    }
    val zkRootDirTxt = new TextField {
      text = "hdfs://localhost:8030/hbase"
    }

    val zkMasterLbl = new Label {
      text = "Master:"
    }
    val zkMasterTxt = new TextField {
      text = "/hbase/master"
    }

    val totalSavedMessagesLbl = new Label {
      text = "Total saved(HBase):"
    }
    val totalSavedMessagesTxt = new TextField {
      text = "0";
      editable = false
    }
    val startBtn = new Button("Start")
    val stopBtn = new Button("Stop")
    listenTo(startBtn, stopBtn)

    reactions += {
      case ButtonClicked(`startBtn`) => startSparkJob
      case ButtonClicked(`stopBtn`) => stopSparkJob
    }

    contents = new BoxPanel(Orientation.Vertical) {
      contents += Swing.VStrut(10)
      val kafkaSettingsPanel = new BoxPanel(Orientation.Horizontal) {
        contents += pollTimeoutLbl
        contents += Swing.HStrut(10)
        contents += pollTimeoutTxt
        contents += Swing.HStrut(20)
        contents += topicLbl
        contents += Swing.HStrut(10)
        contents += topicTxt
        border = BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Kafka settings")
      }

      contents += kafkaSettingsPanel

      contents += Swing.VStrut(10)
      val zookeeperSettingsPanel = new BoxPanel(Orientation.Horizontal) {
        contents += zkTableLbl
        contents += Swing.HStrut(5)
        contents += zkTableTxt
        contents += Swing.HStrut(10)
        contents += zkQuorumLbl
        contents += Swing.HStrut(5)
        contents += zkQuorumTxt
        contents += Swing.HStrut(10)
        contents += zkPortLbl
        contents += Swing.HStrut(5)
        contents += zkPortTxt
        contents += Swing.HStrut(10)
        contents += zkZNodeParentLbl
        contents += Swing.HStrut(5)
        contents += zkZNodeParentTxt
        contents += Swing.HStrut(10)
        contents += zkRootDirLbl
        contents += Swing.HStrut(5)
        contents += zkRootDirTxt
        contents += Swing.HStrut(10)
        contents += zkMasterLbl
        contents += Swing.HStrut(5)
        contents += zkMasterTxt
        border = BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Zookeeper settings")
      }

      contents += zookeeperSettingsPanel
      contents += Swing.VStrut(10)
      contents += new BoxPanel(Orientation.Horizontal) {
        contents += startBtn
        contents += Swing.HStrut(10)
        contents += stopBtn
        contents += Swing.HStrut(500)
        contents += totalSavedMessagesLbl
        contents += totalSavedMessagesTxt
      }
      contents += Swing.VStrut(10)
    }

    private implicit var spark: SparkSession = _
    private implicit var hbase : HBaseProxy = _
    private var sparkJob : KafkaHBJob = _
    private var squery : StreamingQuery = _

    def startSparkJob: Unit = {

      spark = SparkSession
        .builder
        .appName("Project")
        .master("local[*]")
        .getOrCreate()

      hbase = HBaseProxy.apply(
        tableName = zkTableTxt.text,
        zk_quorum = zkQuorumTxt.text,
        zk_port = zkPortTxt.text,
        zk_znode_parent = zkZNodeParentTxt.text,
        rootdir = zkRootDirTxt.text,
        master = zkMasterTxt.text)

      sparkJob = KafkaHBJob.apply("localhost:9092", topicTxt.text)
      if (!sparkJob.isValid) {
        Dialog.showMessage(contents.head, "Invalid input. Please specify kafka topic.", title = "Invalid input", Message.Error)
        return
      }

      if (!hbase.isValid) {
        Dialog.showMessage(contents.head, "Invalid input. Please specify zookeeper values for table name, quorum, port, znode-parent, rootdir and master.", title = "Invalid input", Message.Error)
        return
      }

      try {
        squery = sparkJob.saveStreamToHBase
        timer.start()

      } catch {
        case NonFatal(e) => {
          timer.stop()
          Dialog.showMessage(contents.head, e.getMessage, title = "Error", Message.Error)
        }
      }
    }

    def stopSparkJob: Unit = {

      try {
        if (timer.isRunning)
          timer.stop()

        if(squery.isActive) {
          squery.stop()
        }

        sparkJob.stop
      } catch {
        case NonFatal(e) => {
          Dialog.showMessage(contents.head, e.getMessage, title = "Error", Message.Error)
        }
      }
    }
  }
}
