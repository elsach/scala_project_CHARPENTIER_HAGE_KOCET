package classes

case class Location(latitude: Double, longitude: Double)
case class Bicycle(bicycleId: String, speed : Double, time: Long, location : Location, battery: Int, failed: Boolean){

  def canEqual(a: Any) = a.isInstanceOf[Bicycle]


  override def equals(that: Any): Boolean =
    that match {
      case that: Bicycle => that.canEqual(this) &&
        this.bicycleId == that.bicycleId &&
        this.speed == that.speed &&
	this.location == that.location
	this.battery == that.battery
        this.failed == that.failed
      case _ => false
    } 

  def toJson() : String = {
    s"""
       |{
       |    "bicycleId": "${bicycleId}",
       |    "speed": ${speed},
       |    "time": ${time},
       |    "location": {
       |      "latitude": ${location.latitude},
       |      "longitude": ${location.longitude}
       |     },
       |    "battery" : ${battery},
       |    "failed" : ${failed}
       |},""".stripMargin
  }
}

object Bicycle {
  def parse(json: String) : Bicycle = {
    import org.json4s._
    import org.json4s.jackson.JsonMethods._
    implicit val formats = DefaultFormats
    org.json4s.jackson.JsonMethods.parse(json).extract[Bicycle]
  }
}
