package classes

import java.io.StringWriter
import java.text.SimpleDateFormat
import classes.{Bicycle, Location, Util}
import org.apache.hadoop.hbase.client.{ConnectionFactory, Get, Put, Result}
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{HColumnDescriptor, HTableDescriptor, TableName}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.spark.sql.SparkSession
import scala.util.control.NonFatal

case class HBaseProxy(tableName:String, zk_quorum: String, zk_port: String, zk_znode_parent: String, rootdir: String, master: String) {

  lazy val configuration : Configuration = configure
  lazy val connection = ConnectionFactory.createConnection(configuration)
  lazy val admin = connection.getAdmin
  lazy val currentTable = connection.getTable(TableName.valueOf(tableName))

  private def configure : Configuration = {
    val conf:Configuration = HBaseConfiguration.create()
    conf.set(TableInputFormat.INPUT_TABLE, tableName)
    conf.set("hbase.zookeeper.quorum", "localhost")
    conf.set("hbase.zookeeper.property.clientPort", "2181")
    conf.set("hbase.master", "localhost:16000")
    conf.set("zookeeper.znode.parent", "/hbase-unsecure") /*problem here*/
    conf.set("hbase.rootdir", "hdfs://localhost:8030/hbase")
    conf
  }

  val tn = TableName.valueOf(tableName)

  private def tryTableFunc[P, T <: AnyVal](func: P => T, param : P, maxRetries: Int = 6) : T = {
    var tried: Int = 1
    var done = false
    var result : T = null.asInstanceOf[T]
    val sw = new StringWriter
    var er : java.io.IOException = null

    while (!done && tried <= maxRetries) {
      try {
        result = func(param)
        done = true
      }
      catch {
        case e: java.io.IOException => {
          tried += 1
          Util.randomSleep
          er = e
        }
        case NonFatal(t: Throwable) => throw t
      }
    }

    if(!done)
      throw new Throwable( s"Failed to execute ${func.getClass.getName} after ${maxRetries} attempts.", er)

    result
  }

  def tableExists(tname: TableName) : Boolean = tryTableFunc(admin.tableExists, tname)
  def deleteTable(tname: TableName) : Unit = tryTableFunc(admin.deleteTable, tname)
  def tableIsEnabled(tname: TableName) : Boolean = tryTableFunc(admin.isTableEnabled, tname)
  def enableTable(tname: TableName) : Unit = tryTableFunc(admin.enableTable, tname)
  def tableIsDisabled(tname: TableName) : Boolean = tryTableFunc(admin.isTableDisabled, tname)
  def disableTable(tname: TableName) : Unit = tryTableFunc(admin.disableTable, tname)
  def createTable(desc: HTableDescriptor) : Unit = tryTableFunc(admin.createTable, desc)

  def createOrUpdateTable : Unit = {
    if (tableExists(tn)) {
      if (tableIsEnabled(tn)) {
        disableTable(tn)
        while (!tableIsDisabled(tn)) {
          Util.randomSleep
        }
      }
      deleteTable(tn)
    }

    val tableDescriptor = new HTableDescriptor(tn)
    val columnDescriptor = new HColumnDescriptor(HBaseProxy.columnFamilyName)
    tableDescriptor.addFamily(columnDescriptor)

    if (!tableExists(tn)) createTable(tableDescriptor)

    enableTable(tn)
    while (!tableIsEnabled(tn)){ Util.randomSleep }
  }

  def itemExists(id: String) : Boolean = {
    val bicycleTable = connection.getTable(tn)
    val get = new Get(id.getBytes)
    bicycleTable.exists(get)
  }

  def saveBicycle(bicycle: Bicycle): Unit ={
    if(itemExists(bicycle.bicycleId)) {
      Util.redPrint(s"${bicycle} already exists")
      return
    }

    val bicycleTable = connection.getTable(tn)
    val put = new Put(bicycle.bicycleId.getBytes)

    val date:String = HBaseProxy.iso8601.format(bicycle.time)
    put.addColumn(HBaseProxy.columnFamilyName.getBytes, "bicycleId".getBytes, bicycle.bicycleId.getBytes)
    put.addColumn(HBaseProxy.columnFamilyName.getBytes, "speed".getBytes, Bytes.toBytes(bicycle.speed))
    put.addColumn(HBaseProxy.columnFamilyName.getBytes, "latitude".getBytes, Bytes.toBytes(bicycle.location.latitude))
    put.addColumn(HBaseProxy.columnFamilyName.getBytes, "longitude".getBytes, Bytes.toBytes(bicycle.location.longitude))
    put.addColumn(HBaseProxy.columnFamilyName.getBytes, "time".getBytes, date.getBytes)
    put.addColumn(HBaseProxy.columnFamilyName.getBytes, "battery".getBytes, 
Bytes.toBytes(bicycle.battery))
    put.addColumn(HBaseProxy.columnFamilyName.getBytes, "failed".getBytes, 
Bytes.toBytes(bicycle.failed))
    bicycleTable.put(put)
    bicycleTable.close()

    Util.greenPrint(s"${bicycle} successfully saved.")
  }

  def getAllBicycles()(implicit spark: SparkSession) : Array[Bicycle] = {
    val bicyclesRDD = spark.sparkContext.newAPIHadoopRDD(configuration,
      classOf[TableInputFormat],
      classOf[org.apache.hadoop.hbase.io.ImmutableBytesWritable],
      classOf[org.apache.hadoop.hbase.client.Result])
      .map {
        case (_: ImmutableBytesWritable, value: Result) => HBaseProxy.parseResult(value)
      }

    bicyclesRDD.collect()
  }

  def getCount()(implicit spark: SparkSession) : Long = {
    val bicyclesRDD = spark.sparkContext.newAPIHadoopRDD(configuration,
      classOf[TableInputFormat],
      classOf[org.apache.hadoop.hbase.io.ImmutableBytesWritable],
      classOf[org.apache.hadoop.hbase.client.Result])
      .map {
        case (_: ImmutableBytesWritable, value: Result) => HBaseProxy.parseResult(value)
      }

    bicyclesRDD.count
  }

  def close : Unit = {
      if(!connection.isClosed)
        connection.close()
  }

  val isValid : Boolean = tableName.nonEmpty && zk_quorum.nonEmpty && zk_port.nonEmpty && zk_znode_parent.nonEmpty && rootdir.nonEmpty && master.nonEmpty
}

object HBaseProxy {
  final val columnFamilyName = "BicycleCF"
  final val iso8601:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX")

  def parseResult(value: Result) : Bicycle ={
    val bicycleId = Bytes.toString(value.getRow())
    val speed = Bytes.toInt(value.getValue(columnFamilyName.getBytes, Bytes.toBytes("speed")))
    val latitude = Bytes.toDouble(value.getValue(columnFamilyName.getBytes, Bytes.toBytes("latitude")))
    val longitude = Bytes.toDouble(value.getValue(columnFamilyName.getBytes, Bytes.toBytes("longitude")))
    val time = Bytes.toString(value.getValue(columnFamilyName.getBytes, Bytes.toBytes("time")))
    val battery = Bytes.toInt(value.getValue(columnFamilyName.getBytes, Bytes.toBytes("battery")))
    val failed = Bytes.toBoolean(value.getValue(columnFamilyName.getBytes, Bytes.toBytes("failed")))
    Bicycle(bicycleId, speed, iso8601.parse(time).getTime, Location(latitude, longitude), battery, failed)
  }
}
